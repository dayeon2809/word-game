
import React, { useState, useEffect } from 'react';
import { Quiz } from '@/entities/Quiz';
import { Button } from "@/components/ui/button";
import { RotateCcw, Play } from "lucide-react";
import { motion } from "framer-motion";

import QuizCard from '../components/quiz/QuizCard';
import RelationDisplay from '../components/quiz/RelationDisplay';
import ChoiceButtons from '../components/quiz/ChoiceButtons';
import FeedbackMessage from '../components/quiz/FeedbackMessage';
import ScoreBoard from '../components/quiz/ScoreBoard';

export default function AnalogiesQuiz() {
    const [quizzes, setQuizzes] = useState([]);
    const [currentQuizIndex, setCurrentQuizIndex] = useState(0);
    const [score, setScore] = useState(0);
    const [selectedChoice, setSelectedChoice] = useState(null);
    const [showFeedback, setShowFeedback] = useState(false);
    const [isCorrect, setIsCorrect] = useState(false);
    const [showAnswer, setShowAnswer] = useState(false);
    const [gameStarted, setGameStarted] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    const createSampleQuizzes = async () => {
        const sampleQuizzes = [
            {
                question_a: "👶",
                question_b: "🍼", 
                question_c: "👨",
                correct_answer: "☕",
                wrong_options: ["🥛", "🧃"],
                level: "쉬움"
            },
            {
                question_a: "🐱", 
                question_b: "🐟",
                question_c: "🐶",
                correct_answer: "🦴",
                wrong_options: ["🥕", "🍎"],
                level: "쉬움"
            },
            {
                question_a: "☀️",
                question_b: "🌅",
                question_c: "🌙",
                correct_answer: "🌃",
                wrong_options: ["⭐", "🌈"],
                level: "보통"
            },
            {
                question_a: "🔥",
                question_b: "🚒",
                question_c: "🏥",
                correct_answer: "🚑",
                wrong_options: ["🚌", "🚗"],
                level: "보통"
            },
            {
                question_a: "📚",
                question_b: "🏫",
                question_c: "💊",
                correct_answer: "🏥",
                wrong_options: ["🏪", "🏨"],
                level: "어려움"
            }
        ];

        for (const quiz of sampleQuizzes) {
            await Quiz.create(quiz);
        }
    };

    useEffect(() => {
        const loadQuizzes = async () => {
            setIsLoading(true);
            const data = await Quiz.list();
            if (data.length > 0) {
                setQuizzes(data);
            } else {
                // 퀴즈가 없으면 샘플 퀴즈 생성
                await createSampleQuizzes();
                const newData = await Quiz.list();
                setQuizzes(newData);
            }
            setIsLoading(false);
        };

        loadQuizzes();
    }, []);

    const startGame = () => {
        setGameStarted(true);
        resetGame();
    };

    const resetGame = () => {
        setCurrentQuizIndex(0);
        setScore(0);
        setSelectedChoice(null);
        setShowFeedback(false);
        setIsCorrect(false);
        setShowAnswer(false);
    };

    const handleChoiceSelect = (choice) => {
        if (showFeedback) return;

        const currentQuiz = quizzes[currentQuizIndex];
        const correct = choice === currentQuiz.correct_answer;
        
        setSelectedChoice(choice);
        setIsCorrect(correct);
        setShowFeedback(true);
        setShowAnswer(true);

        if (correct) {
            setScore(prev => prev + 1);
        }
    };

    const nextQuestion = () => {
        if (currentQuizIndex < quizzes.length - 1) {
            setCurrentQuizIndex(prev => prev + 1);
        } else {
            setCurrentQuizIndex(0);
        }
        
        setSelectedChoice(null);
        setShowFeedback(false);
        setIsCorrect(false);
        setShowAnswer(false);
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
                <div className="text-center">
                    <div className="text-6xl mb-4">🎯</div>
                    <div className="text-2xl font-bold text-gray-600">문제를 준비하고 있어요...</div>
                </div>
            </div>
        );
    }

    if (!gameStarted) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-6">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center"
                >
                    <QuizCard className="max-w-lg mx-auto bg-gradient-to-br from-yellow-100 to-orange-100">
                        <div className="text-8xl mb-6">🧩</div>
                        <h1 className="text-4xl font-bold text-gray-800 mb-4">유추 퀴즈</h1>
                        <p className="text-xl text-gray-600 mb-8">
                            그림을 보고 관계를 찾아보세요!
                        </p>
                        <Button
                            onClick={startGame}
                            className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white text-2xl py-6 px-12 rounded-2xl shadow-lg"
                        >
                            <Play className="w-6 h-6 mr-3" />
                            시작하기
                        </Button>
                    </QuizCard>
                </motion.div>
            </div>
        );
    }

    if (quizzes.length === 0) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center">
                <div className="text-center">
                    <div className="text-6xl mb-4">📝</div>
                    <div className="text-2xl font-bold text-gray-600">아직 퀴즈가 없어요</div>
                </div>
            </div>
        );
    }

    const currentQuiz = quizzes[currentQuizIndex];
    const allChoices = [currentQuiz.correct_answer, ...currentQuiz.wrong_options].sort(() => Math.random() - 0.5);

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-6">
            <div className="max-w-4xl mx-auto">
                <ScoreBoard 
                    currentScore={score}
                    totalQuestions={quizzes.length}
                    currentQuestion={currentQuizIndex}
                />

                <motion.div
                    key={currentQuizIndex}
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3 }}
                >
                    <RelationDisplay
                        a={currentQuiz.question_a}
                        b={currentQuiz.question_b}
                        c={currentQuiz.question_c}
                        showAnswer={showAnswer}
                        answer={currentQuiz.correct_answer}
                    />

                    <ChoiceButtons
                        choices={allChoices}
                        selectedChoice={selectedChoice}
                        onChoiceSelect={handleChoiceSelect}
                        correctAnswer={currentQuiz.correct_answer}
                        showFeedback={showFeedback}
                    />

                    <FeedbackMessage 
                        isCorrect={isCorrect}
                        show={showFeedback}
                    />

                    <div className="flex justify-center gap-4">
                        {showFeedback && (
                            <Button
                                onClick={nextQuestion}
                                className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white text-xl py-4 px-8 rounded-2xl shadow-lg"
                            >
                                다음 문제 ▶
                            </Button>
                        )}
                        
                        <Button
                            onClick={resetGame}
                            variant="outline"
                            className="text-xl py-4 px-8 rounded-2xl shadow-lg border-2"
                        >
                            <RotateCcw className="w-5 h-5 mr-2" />
                            점수 초기화
                        </Button>
                    </div>
                </motion.div>
            </div>
        </div>
    );
}
