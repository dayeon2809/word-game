
export const Quiz = {
  "name": "Quiz",
  "type": "object",
  "properties": {
    "question_a": {
      "type": "string",
      "description": "첫 번째 관계의 A (이모지 또는 단어)"
    },
    "question_b": {
      "type": "string",
      "description": "첫 번째 관계의 B (이모지 또는 단어)"
    },
    "question_c": {
      "type": "string",
      "description": "두 번째 관계의 C (이모지 또는 단어)"
    },
    "correct_answer": {
      "type": "string",
      "description": "정답 (이모지 또는 단어)"
    },
    "wrong_options": {
      "type": "array",
      "items": {
        "type": "string"
      },
      "description": "오답 선택지들"
    },
    "level": {
      "type": "string",
      "enum": [
        "쉬움",
        "보통",
        "어려움"
      ],
      "default": "쉬움",
      "description": "문제 난이도"
    }
  },
  "required": [
    "question_a",
    "question_b",
    "question_c",
    "correct_answer",
    "wrong_options"
  ]
}