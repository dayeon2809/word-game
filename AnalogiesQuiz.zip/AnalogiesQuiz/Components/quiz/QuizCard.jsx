import React from 'react';
import { Card } from "@/components/ui/card";

export default function QuizCard({ children, className = "" }) {
    return (
        <Card className={`bg-white shadow-lg border-0 rounded-3xl p-6 ${className}`}>
            {children}
        </Card>
    );
}