import React from 'react';
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import QuizCard from './QuizCard';
import { RotateCcw } from "lucide-react";

export default function ResultScreen({ score, totalQuestions, onRestart }) {
    const percentage = Math.round((score / totalQuestions) * 100);
    
    const getFeedbackMessage = () => {
        if (percentage >= 90) return "완벽해요! 🏆";
        if (percentage >= 80) return "아주 잘했어요! 🌟";
        if (percentage >= 70) return "잘했어요! 👏";
        if (percentage >= 60) return "좋아요! 😊";
        return "다음에는 더 잘할 수 있어요! 💪";
    };

    const getEmoji = () => {
        if (percentage >= 90) return "🏆";
        if (percentage >= 80) return "🌟";
        if (percentage >= 70) return "👏";
        if (percentage >= 60) return "😊";
        return "💪";
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-6">
            <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                className="text-center"
            >
                <QuizCard className="max-w-lg mx-auto bg-gradient-to-br from-yellow-100 to-orange-100">
                    <div className="text-8xl mb-6">{getEmoji()}</div>
                    
                    <h1 className="text-4xl font-bold text-gray-800 mb-6">퀴즈 완료!</h1>
                    
                    <div className="bg-white rounded-2xl p-6 mb-6 shadow-inner">
                        <div className="text-6xl font-bold text-blue-600 mb-2">
                            {score} / {totalQuestions}
                        </div>
                        <div className="text-xl text-gray-600">
                            {totalQuestions}문항 중 {score}문항 정답
                        </div>
                        <div className="text-lg text-gray-500 mt-2">
                            정답률: {percentage}%
                        </div>
                    </div>

                    <div className="text-3xl font-bold text-gray-700 mb-8">
                        {getFeedbackMessage()}
                    </div>

                    <Button
                        onClick={onRestart}
                        className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white text-2xl py-6 px-12 rounded-2xl shadow-lg"
                    >
                        <RotateCcw className="w-6 h-6 mr-3" />
                        다시 시작하기
                    </Button>
                </QuizCard>
            </motion.div>
        </div>
    );
}