import React from 'react';
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { RotateCcw } from "lucide-react";

export default function FeedbackMessage({ isCorrect, show, onRetry }) {
    return (
        <AnimatePresence>
            {show && (
                <motion.div
                    initial={{ opacity: 0, y: -20, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -20, scale: 0.8 }}
                    className="text-center mb-6"
                >
                    <div className={`text-6xl mb-2 ${isCorrect ? 'text-green-500' : 'text-orange-500'}`}>
                        {isCorrect ? '🎉' : '🤔'}
                    </div>
                    <div className={`text-3xl font-bold mb-4 ${isCorrect ? 'text-green-600' : 'text-orange-600'}`}>
                        {isCorrect ? '정답! 👏' : '틀렸어! 다시 시도해봐 🤔'}
                    </div>
                    
                    {!isCorrect && onRetry && (
                        <Button
                            onClick={onRetry}
                            className="bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white text-xl py-4 px-8 rounded-2xl shadow-lg"
                        >
                            <RotateCcw className="w-5 h-5 mr-2" />
                            다시 시도하기
                        </Button>
                    )}
                </motion.div>
            )}
        </AnimatePresence>
    );
}