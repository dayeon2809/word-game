import React, { useEffect } from 'react';

export default function AudioManager({ 
    playCorrectSound, 
    playWrongSound 
}) {
    useEffect(() => {
        // 정답 효과음 - 밝고 긍정적인 사운드
        if (playCorrectSound) {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            // 아름다운 화음 (C major arpeggio)
            const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
            
            notes.forEach((freq, index) => {
                const oscillator = audioContext.createOscillator();
                const gainNode = audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(freq, audioContext.currentTime);
                
                const startTime = audioContext.currentTime + (index * 0.1);
                gainNode.gain.setValueAtTime(0.2, startTime);
                gainNode.gain.exponentialRampToValueAtTime(0.001, startTime + 0.6);
                
                oscillator.start(startTime);
                oscillator.stop(startTime + 0.6);
            });
        }
    }, [playCorrectSound]);

    useEffect(() => {
        // 오답 효과음 - 부드러운 실망음
        if (playWrongSound) {
            const audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = audioContext.createOscillator();
            const gainNode = audioContext.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(audioContext.destination);
            
            oscillator.type = 'sine';
            // 부드럽게 하강하는 음
            oscillator.frequency.setValueAtTime(300, audioContext.currentTime);
            oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.4);
            
            gainNode.gain.setValueAtTime(0.15, audioContext.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.4);
            
            oscillator.start();
            oscillator.stop(audioContext.currentTime + 0.4);
        }
    }, [playWrongSound]);

    return null;
}