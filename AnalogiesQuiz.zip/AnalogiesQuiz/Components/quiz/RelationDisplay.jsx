import React from 'react';
import QuizCard from './QuizCard';

export default function RelationDisplay({ a, b, c, showAnswer, answer }) {
    return (
        <div className="grid grid-cols-2 gap-6 mb-8">
            {/* 예시 관계 */}
            <QuizCard className="bg-gradient-to-br from-blue-50 to-indigo-100">
                <div className="text-center">
                    <div className="text-6xl mb-3">{a}</div>
                    <div className="text-2xl text-gray-500 mb-3">:</div>
                    <div className="text-6xl">{b}</div>
                </div>
            </QuizCard>

            {/* 문제 관계 */}
            <QuizCard className="bg-gradient-to-br from-pink-50 to-rose-100">
                <div className="text-center">
                    <div className="text-6xl mb-3">{c}</div>
                    <div className="text-2xl text-gray-500 mb-3">:</div>
                    <div className="text-6xl min-h-[80px] flex items-center justify-center">
                        {showAnswer ? answer : "?"}
                    </div>
                </div>
            </QuizCard>
        </div>
    );
}