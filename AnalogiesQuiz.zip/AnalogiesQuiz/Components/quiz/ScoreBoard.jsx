import React from 'react';
import { Card } from "@/components/ui/card";

export default function ScoreBoard({ currentScore, totalQuestions, currentQuestion }) {
    return (
        <Card className="bg-gradient-to-r from-purple-100 to-pink-100 border-0 rounded-2xl p-4 mb-6">
            <div className="flex justify-center items-center gap-6 text-lg font-bold text-gray-700">
                <div className="flex items-center gap-2">
                    <span className="text-2xl">📊</span>
                    <span>점수: {currentScore}점</span>
                </div>
                <div className="flex items-center gap-2">
                    <span className="text-2xl">📚</span>
                    <span>{currentQuestion + 1} / {totalQuestions}문제</span>
                </div>
            </div>
        </Card>
    );
}