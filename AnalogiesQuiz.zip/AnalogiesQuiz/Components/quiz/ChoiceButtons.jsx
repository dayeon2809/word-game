import React from 'react';
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function ChoiceButtons({ 
    choices, 
    selectedChoice, 
    onChoiceSelect, 
    correctAnswer,
    showFeedback 
}) {
    return (
        <div className="flex justify-center gap-6 mb-8">
            {choices.map((choice, index) => {
                let buttonClass = "h-24 w-24 text-4xl rounded-full shadow-lg transition-all duration-300 ";
                
                if (showFeedback) {
                    if (choice === correctAnswer) {
                        buttonClass += "bg-gradient-to-br from-green-400 to-green-500 text-white shadow-green-300 ";
                    } else if (choice === selectedChoice) {
                        buttonClass += "bg-gradient-to-br from-red-400 to-red-500 text-white shadow-red-300 ";
                    } else {
                        buttonClass += "bg-gradient-to-br from-gray-200 to-gray-300 text-gray-600 ";
                    }
                } else {
                    buttonClass += "bg-gradient-to-br from-yellow-200 to-amber-300 hover:from-yellow-300 hover:to-amber-400 hover:shadow-xl hover:scale-105 text-gray-700 ";
                }

                return (
                    <motion.div
                        key={index}
                        whileHover={{ scale: showFeedback ? 1 : 1.05 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        <Button
                            className={buttonClass}
                            onClick={() => onChoiceSelect(choice)}
                            disabled={showFeedback}
                        >
                            {choice}
                        </Button>
                    </motion.div>
                );
            })}
        </div>
    );
}